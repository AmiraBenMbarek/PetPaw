document.querySelector('.img-btn').addEventListener('click', function()
	{ 
		document.querySelector('.cont').classList.toggle('s-signup')
	}
);
/* La méthode querySelector() de l'interface Document retourne le premier Element dans le
 document correspondant au sélecteur */ 
 /*The classList property returns the class name(s) of an element*/
 /* toggle = basculer */