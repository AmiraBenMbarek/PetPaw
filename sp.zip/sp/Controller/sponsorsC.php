<?php
	include 'C:/xampp/htdocs/sp/config.php';
	include_once 'C:/xampp/htdocs/sp/Model/sponsors.php';
	class sponsorsC {
		function affichersponsors(){
			$sql="SELECT * FROM sponsors";
			$db = config::getConnexion();
			try{
				$liste = $db->query($sql);
				return $liste;
			}
			catch(Exception $e){
				die('Erreur:'. $e->getMeesage());
			}
		}
		function supprimersponsors($id){
			$sql="DELETE FROM sponsors WHERE id_sp=:id_sp";
			$db = config::getConnexion();
			$req=$db->prepare($sql);
			$req->bindValue(':id_sp', $id);
			try{
				$req->execute();
			}
			catch(Exception $e){
				die('Erreur:'. $e->getMeesage());
			}
		}
		function ajoutersponsors($sponsors){
			$sql="INSERT INTO sponsors (id_sp,name_sp,type_sp,numtel_sp,mail_sp,inves_sp,image_sp,descrip_sp) 
			VALUES (:id_sp,:name_sp,:type_sp,:numtel_sp,:mail_sp,:inves_sp,:image_sp,:descrip_sp)";
			$db = config::getConnexion();
			try{
				$query = $db->prepare($sql);
				$query->execute([
					'id_sp' => $sponsors->getid(),
					'name_sp' => $sponsors->getNom(),
					'type_sp' => $sponsors->gettype(),
					'numtel_sp' => $sponsors->getnumero(),
                    'mail_sp'=> $sponsors-> getEmail(),
                    'inves_sp'=> $sponsors->getinves(),
					'image_sp'=> $sponsors->getimage(),
                    'descrip_sp'=> $sponsors->getdescrip()

				]);			
			}
			catch (Exception $e){
				echo 'Erreur: '.$e->getMessage();
			}			
		}
		function recuperersponsors($id){
			$sql="SELECT * from sponsors where id_sp=$id";
			$db = config::getConnexion();
			try{
				$query=$db->prepare($sql);
				$query->execute();

				$sponsors=$query->fetch();
				return $sponsors;
			}
			catch (Exception $e){
				die('Erreur: '.$e->getMessage());
			}
		}
		
		function modifiersponsors($sponsors, $id){
			try {
				$db = config::getConnexion();
				$query = $db->prepare(
					'UPDATE sponsors SET 

						name_sp= :name_sp,
						type_sp= :type_sp,
						numtel_sp= :numtel_sp,
						mail_sp= :mail_sp,
						inves_sp= :inves_sp,
						image_sp= :image_sp,
						descrip_sp= :descrip_sp
						
					WHERE id_sp= :id_sp'
				);
				$query->execute([
					
					
					'name_sp' => $sponsors->getNom(),
					'type_sp' => $sponsors->gettype(),
					'numtel_sp' => $sponsors->getnumero(),
                    'mail_sp'=> $sponsors-> getEmail(),
                    'inves_sp'=> $sponsors->getinves(),
					'image_sp'=> $sponsors->getimage(),
                    'descrip_sp'=> $sponsors->getdescrip(),
					
					'id_sp' => $id

					
				]);
				echo $query->rowCount() . " records UPDATED successfully <br>";
			} catch (PDOException $e) {
				$e->getMessage();
			}
		}

	}
?>